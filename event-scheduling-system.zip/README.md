# 📅 Event Scheduling System

The **Event Scheduling System** is a Java-based application that simplifies event planning, organizing, and monitoring processes.  
Organizers can create and manage events, while participants can register and view details easily.

---

## 🚀 Features
- **Create Event** → Store details such as name, date, and location.  
- **Register for Event** → Allow users to register for specific events.  
- **Show All Events** → Display a list of all scheduled events.  
- **Show Event Details** → View full details and list of attendees.  

---

## 🏗️ System Architecture
The project follows OOP principles in Java:
- **Encapsulation** → Classes manage their own data and behavior.  
- **Abstraction** → Users interact through high-level methods.  
- **Modularity** → Separate classes for better organization.  

📌 *(Flowchart available in `/docs/flowchart.png`)*

---

## 📂 Project Structure
```
event-scheduling-system/
│── src/                    # Java source code
│   └── EventScheduler.java
│── docs/                   # Flowchart and project documentation
│   └── flowchart.png
│── README.md
│── .gitignore
```

---

## ⚙️ Technologies Used
- Language: **Java**
- Concepts: **OOP (Encapsulation, Abstraction, Modularity)**

---

## 📌 Future Enhancements
- Add database support (MySQL/SQLite)  
- Add user authentication for event managers  
- GUI for better interaction  

---

## 👩‍💻 Author
**Pallavi P**  
Register No: 8115U23CS077  
Roll No: CSB2315  
Year & Section: II / B  

---

## 📜 License
This project is for educational purposes.
