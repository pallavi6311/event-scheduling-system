import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Event {
    private String name;
    private String date;
    private String location;
    private List<String> attendees;

    public Event(String name, String date, String location) {
        this.name = name;
        this.date = date;
        this.location = location;
        this.attendees = new ArrayList<>();
    }

    public void registerAttendee(String attendee) {
        attendees.add(attendee);
        System.out.println("✅ " + attendee + " registered for " + name);
    }

    public void displayAttendees() {
        System.out.println("Attendees for " + name + ":");
        if (attendees.isEmpty()) {
            System.out.println("No attendees registered yet.");
        } else {
            for (String attendee : attendees) {
                System.out.println("- " + attendee);
            }
        }
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Event: " + name + " | Date: " + date + " | Location: " + location + " | Attendees: " + attendees.size();
    }

    public void showDetails() {
        System.out.println(this.toString());
        displayAttendees();
    }
}

public class EventScheduler {
    private static List<Event> events = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n📅 Event Scheduling System");
            System.out.println("1. Create Event");
            System.out.println("2. Register for Event");
            System.out.println("3. Show All Events");
            System.out.println("4. Show Event Details");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1 -> createEvent();
                case 2 -> registerForEvent();
                case 3 -> showAllEvents();
                case 4 -> showEventDetails();
                case 5 -> System.out.println("Exiting... Thank you!");
                default -> System.out.println("Invalid choice, try again.");
            }
        } while (choice != 5);
    }

    private static void createEvent() {
        System.out.print("Enter event name: ");
        String name = sc.nextLine();
        System.out.print("Enter event date: ");
        String date = sc.nextLine();
        System.out.print("Enter event location: ");
        String location = sc.nextLine();

        Event event = new Event(name, date, location);
        events.add(event);
        System.out.println("✅ Event created successfully!");
    }

    private static void registerForEvent() {
        if (events.isEmpty()) {
            System.out.println("⚠️ No events available to register.");
            return;
        }
        showAllEvents();
        System.out.print("Enter event name to register: ");
        String name = sc.nextLine();
        for (Event event : events) {
            if (event.getName().equalsIgnoreCase(name)) {
                System.out.print("Enter your name: ");
                String attendee = sc.nextLine();
                event.registerAttendee(attendee);
                return;
            }
        }
        System.out.println("⚠️ Event not found!");
    }

    private static void showAllEvents() {
        if (events.isEmpty()) {
            System.out.println("⚠️ No events scheduled yet.");
        } else {
            System.out.println("\n📋 All Events:");
            for (Event event : events) {
                System.out.println(event.toString());
            }
        }
    }

    private static void showEventDetails() {
        if (events.isEmpty()) {
            System.out.println("⚠️ No events scheduled.");
            return;
        }
        System.out.print("Enter event name to view details: ");
        String name = sc.nextLine();
        for (Event event : events) {
            if (event.getName().equalsIgnoreCase(name)) {
                event.showDetails();
                return;
            }
        }
        System.out.println("⚠️ Event not found!");
    }
}
